package com.multi;


public class CityVO {
    private int ID;
    private String Name;
    private String CountryCode;
    private String District;
    private int Population;

    //문제 4-1. 각 필드에 대한 GET/SET/toString메서드를 구현하시오.
    //          단, toString()메서드는 오버라이드하여 구현하고,
    //          모든 필드의 값이 "하나의 String타입"으로 반환되어야 함.

        /***********************************************
     * 구현 코드
     *
     *
     *
     */
}