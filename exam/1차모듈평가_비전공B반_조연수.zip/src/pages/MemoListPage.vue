<script setup>
import MemoList from '@/components/MemoList.vue';
import { ref, reactive, provide } from 'vue';
import axios from 'axios';

const BASE = '/api/memo';

// 문제2. src/pages/MemoLsitPage.vue에서는 메모 목록을 서버로부터 받아, MemoList 컴포넌트로 전달한다.
// 스크립트 파트를 완성하세요.
// 문법을 모르니까 하나도 못하겠어요.. 몬 느낌인지는 아는데 하...
// 외울걸 ... 외울걸..... ㅠㅠㅠ 외울걸 ㅝㅏㅠ어노란머유류ㅠㅠㅠㅠ


function load() {
  const memos = [];

  // memos.push(axios.get(BASE, "memo"))
  memos.push(axios.get(BASE, "memo"));
  const states = reactive(memos);
  console.log(memos);
  return memos;

  // provide('memos');
}

// function load() {
//   const memos = [
//     {
//       id: "a001",
//       title: "첫 번째 메모",
//       content: "메모1"
//     },
//     {
//       id: "a002",
//       title: "두 번째 메모",
//       content: "메모2"
//     },
//     {
//       id: "a003",
//       title: "세 번째 메모",
//       content: "메모3"
//     },
//     {
//       id: "a004",
//       title: "네 번째 메모",
//       content: "메모4"
//     }
//   ];
//   console.log(memos);
//   const states = reactive(memos);
//   return memos;
// };




///////

load(); //초기 데이터 로드 함수 호출
</script>

<template>
  <h2>Memo 목록</h2>
  <MemoList :memos="memos" />

  <div>
    <router-link to="/memo/write">새 메모</router-link>
  </div>
</template>

<style scoped></style>
