<script setup>
import { RouterView } from 'vue-router';
</script>

<template>
  <h1>메모 앱</h1>
  <RouterView />
</template>

<style scoped></style>
