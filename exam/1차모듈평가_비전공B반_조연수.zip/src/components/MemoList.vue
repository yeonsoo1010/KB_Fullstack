<script setup>
import MemoItem from './MemoItem.vue';
import MemoListPage from "@/pages/MemoListPage.vue";
import {provide, inject} from 'vue';

// 문제 3. memos 프로퍼티를 정의하세요.
defineProps({
  memos: { type: Object, required: true },
});
</script>

<!-- <script>
import MemoItem from "./MemoItem.vue";

export default (
  name: "memoList",
  component: { MemoItem },
  data(){
    return{
      "memos": {
        id: memo.id,
        title: memo.title,
      }
    }
  }
) -->


<!-- <script>
import MemoItem from "./MemoItem.vue";

export default (
  name: "memoList",
  component: { MemoItem },
  props: [memos],
)
</script> -->
<!-- 부모에서 name, component,data, 자식에서 name, props
todoList: [
   {id: 1, name: "", done: true},
   {id: 2, name: "", done: false} 뭐 이런 느낌이었는데
] -->

<template>
  <table style="width: 100%">
    <thead>
      <tr>
        <th style="width: 50px">id</th>
        <th>title</th>
      </tr>
    </thead>

    <tbody>
      <!-- 문제 3. memos 프로퍼티로 MemoItem 컴포넌트를 메모 수 만큼 렌더링 하세요. -->
      <tr v-for="memo in memos" :key="memo.id">
        <!-- v-for문을 이용할 것 같은데 :key="memoItem.id" -->
        <td>{{ memo.id }}</td>
        <td>{{ memo.title }}</td>
      </tr>
    </tbody>
  </table>
</template>

<style scoped></style>
