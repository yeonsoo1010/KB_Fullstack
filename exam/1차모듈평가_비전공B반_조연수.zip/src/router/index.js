import MemoDetailPage from '@/pages/MemoDetailPage.vue';
import MemoWritePage from '@/pages/MemoWritePage.vue';
import MemoListPage from '../pages/MemoListPage.vue';
import { createRouter, createWebHistory } from 'vue-router';
const HomeView = () => import('../pages/MemoListPage.vue');

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    { path: '/', name: 'home', component: HomeView },
    { path: "/memo", name: "memoList", component: MemoListPage },
    { path: "/memo/view/:id", name: "memoDetail", component: MemoDetailPage },
    { path: "memo/write", name: "memoWrite", component: MemoWritePage }
    // 1.	라우터 테이블을 완성하세요.
    // 왜 안나올까? 틀린 게 없는데... 각 페이지의 내용이 비거나 이상해서 그런 것 같음.
  ],
});

export default router;
